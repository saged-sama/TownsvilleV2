#ifndef MATHS_H
#define MATHS_H

int getgcd();
unsigned long long int calculateResources();
void timeAndResourceManagement();
void calcraid();

#endif