#ifndef BUILDMENU_H
#define BUILDMENU_H

#include "texture.h"
#include "gFunctions.h"

void render_buildMenu();
bool loadMedia_buildMenu();
bool handleEvent_buildCommand(int x, int y);

#endif