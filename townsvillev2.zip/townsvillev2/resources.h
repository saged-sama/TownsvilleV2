#ifndef RESOURCES_H
#define RESOURCES_H

#include <bits/stdc++.h>
#include <SDL2/SDL_ttf.h>

void render_resources();
bool loadMedia_topbar();

#endif