#ifndef NOTIF_H
#define NOTIF_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <bits/stdc++.h>

void render_message(std::string s);

bool loadMedia_notifbar();

#endif