#ifndef BUILD_H
#define BUILD_H

#include <bits/stdc++.h>
#include "gFunctions.h"
#include "texture.h"

std::string build(std::string buildCommand, SDL_Event e);

#endif