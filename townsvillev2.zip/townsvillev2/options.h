#ifndef OPTIONS_H
#define OPTIONS_H

#include "texture.h"

void render_inGameOptions();
bool loadMedia_options();

#endif